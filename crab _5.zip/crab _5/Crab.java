import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Crab extends Actor
{
    private GreenfootImage image1;
    private GreenfootImage image2;
    /**
     * Create a crab and initializes its images
     */
    public Crab()
    {
        image1 = new GreenfootImage("crab.png");
        image2 = new GreenfootImage("crab2.png");
        setImage(image1);
    }
    /**
     * Act - do whatever the Crab wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move();
        tryToEat();
        switchImage();
    }  
    public void move()
    {
        if ( isAtEdge() )
        {
            turn(17);
        }
        move(17);
        if ( Greenfoot.getRandomNumber(100)<7 )
        {
             turn(Greenfoot.getRandomNumber(91)-45);
        }
    }
    public void tryToEat()
    {
         if ( isTouching(Worm.class) )
        {
            removeTouching(Worm.class);
            Greenfoot.playSound("eating.wav");
        }
    }
    public void switchImage()
    {
        if (getImage() == image1) 
        {
            setImage(image2);
        }
        else
        {
            setImage(image1);
        }
    }
}
