import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Crab extends Actor
{
    private static GreenfootImage image1;
    private static GreenfootImage image2;
    private static int wormsEaten;
    /**
     * Create a crab and initializes its images
     */
    public Crab()
    {
        wormsEaten = 0;
        image1 = new GreenfootImage("crab.png");
        image2 = new GreenfootImage("crab2.png");
        setImage(image1);
    }
    /**
     * Act - do whatever the Crab wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move();
        tryToEat();
        switchImage();
    }  
    public void move()
    {
        if ( isAtEdge() )
        {
            turn(17);
        }
        move(17);
        if ( Greenfoot.getRandomNumber(100)<7 )
        {
             turn(Greenfoot.getRandomNumber(91)-45);
        }
    }
    public void tryToEat()
    {
         if ( isTouching(Worm.class) )
        {
            wormsEaten++;
            removeTouching(Worm.class);
            Greenfoot.playSound("eating.wav");
            if ( wormsEaten >= 10 )
            {
                Greenfoot.playSound("lost.wav");
                Greenfoot.stop();
            }
        }
    }
    public void switchImage()
    {
        if (getImage() == image1) 
        {
            setImage(image2);
        }
        else
        {
            setImage(image1);
        }
    }
}
