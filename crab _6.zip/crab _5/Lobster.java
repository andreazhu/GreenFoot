import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Lobster here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lobster extends Actor
{
    private static int crabsEaten = 0;
    /**
     * Act - do whatever the Lobster wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move();
        tryToEat();
    } 
    public void move()
    {
        move(14);
        if ( Greenfoot.isKeyDown("left") )
        {
            turn(-10);
        }
        if ( Greenfoot.isKeyDown("Right") )
        {
            turn(10);
        }
        if ( isAtEdge() )
        {
            turn(30);
        }
    }
    public void tryToEat()
    {
         if ( isTouching(Crab.class) )
        {
            crabsEaten++;
            removeTouching(Crab.class);
            Greenfoot.playSound("Lobster.wav");
            if ( crabsEaten == 3 )
            {
                Greenfoot.playSound("won.wav");
                Greenfoot.stop();
            }
        }
       
    }
}
